﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JeuDroides.Core.Models
{
    public class Avatar
    {
        public string Nom;
        public string Genre;
        public Espece MonEspece;
        public Role MonRole;
    }
}