﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JeuDroides.Core.Models
{
    public class Utilisateur
    {
        public string Login;
        public Avatar MonAvatar;
    }
}
